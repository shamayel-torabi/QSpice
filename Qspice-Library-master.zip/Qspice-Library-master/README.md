**Qspice Library for Würth Elektronik Products**
=

## Introduction
Qspice is a SPICE simulator from Qorvo for analog and mixed signal systems.

For how to use models in GitHub repository, you can refer to the help document in this folder.

**Please read Disclaimer carefully before downloading and using Würth Elektronik Models.**

**Note: Qspice Library is still under constant development.**
**Please contact libraries@we-online.com, if there is any problem.**

## Component Classification
* WE - Automotive
  
  * Power Inductors
* WE - Power Magnetics

  * Inductors
  * Transformers
